# Introduction 

Automation Testing with Selenium & Java. Foundation Level framwork designed for Web, Mainframe, API and SQL using BDD and TestNG

## Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Build and Test

### 1.Installation process

Install Java version 8

Eclipse or IntelliJ IDE  - https://www.eclipse.org/downloads/

Maven - https://www.javatpoint.com/how-to-install-maven

Git -https://git-scm.com/book/en/v2/Getting-Started-Installing-Git 

### 2.Software dependencies
All the dependecnies can be resolved from Maven Dependency.

### 3.Build and Test

#### Process1:
Download the zip or clone the Git repository.

Unzip the zip file (if you downloaded one).

Open Command Prompt and Change directory (cd) to folder containing pom.xml

Type mvn clean test -DsuiteXmlFile=xmlfilename -Dbrowser=browsername

	1. xmlfilename -- This Parameter is used to switch between any xml testng files
	2. browsername -- It can be any browser (chrome or edge or firefox)

#### Process2:
Open Eclipse

File -> Import -> Existing Maven Project -> Navigate to the folder where you unzipped the zip

Select the right project

Right Click on the file and Run as Testng Application

You are all Set !!!
