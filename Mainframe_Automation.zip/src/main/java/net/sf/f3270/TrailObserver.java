package net.sf.f3270;

public class TrailObserver {

}
