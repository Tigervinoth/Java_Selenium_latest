package utils;
import java.io.*;


public class FileUtil {

    File file;
    BufferedReader br;

    /**
     * @param fileName
     * @throws FileNotFoundException
     */
    public FileUtil(String fileName)  {
       this.file = new File(fileName);
    }

    /**
     *This method is created to create file
     */
    public void CreateFile(){
        try{
            if(file.exists()){
                System.out.println("File exists");
                file.delete();
                file.createNewFile();
            }
            else{
                file.createNewFile();
                System.out.println("File created");
            }
        }catch(IOException e){
            System.out.println("Faced error in creating file");
            e.printStackTrace();
        }
    }

    /**
     *This method is created to create directory
     */
    public void CreateDirectory(){
        if(file.exists()){
            System.out.println("Directory already exists");
            file.delete();
            file.mkdir();

        }
        else{
            file.mkdir();
            System.out.println("Directory created");
        }

    }

    /**
     *This method is created to get file information
     */
    public void FileInformation(){
        if(file.exists()){
            System.out.println("File name:"+file.getName());
            System.out.println("File path:"+file.getAbsolutePath());
            System.out.println("File size:"+file.length());
            if(file.isDirectory()){
                System.out.println("Directory");
            }
            else{
                System.out.println("File");
            }
        }
        else{
            System.out.println("File does not exists");
        }

    }

    /**
     * This method is created to write into file
     */
    public void WriteToFile(String content){
        try {
            FileWriter newObj = new FileWriter(file);
            newObj.write(content);
            newObj.close();
            System.out.println("Wrote to file");

        } catch (IOException e) {
            System.out.println("Error occured");
            e.printStackTrace();
        }

    }

    /**
     * This method is created to read from file
     * @throws IOException
     */
    public void UsingBufferedReader() throws IOException {
        try{
            br = new BufferedReader(new FileReader(file));
            System.out.println("Content in file:");
            int c=0;
            while((c=br.read())!=-1) {
                System.out.print((char) c);
            }

        }catch(FileNotFoundException e) {
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            br.close();
        }
    }

    /**
     * This method is created to delete a directory and files within it
     * @param
     */
    public void deleteDirectory() {
        try {
            if(file.exists()){
                for (File subfile : file.listFiles()) {
                    if (subfile.isDirectory()) {
                        deleteDirectory();
                    }
                    subfile.delete();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
