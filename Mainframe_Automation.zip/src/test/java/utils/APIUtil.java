package utils;


import java.util.HashMap;
import java.util.Map;

import apimodel.APIBuilder;
import io.restassured.RestAssured;
import io.restassured.authentication.AuthenticationScheme;
import io.restassured.authentication.CertificateAuthSettings;
import io.restassured.authentication.FormAuthConfig;
import io.restassured.authentication.OAuthSignature;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.MatcherAssert.assertThat;

public class APIUtil{

    private String baseUrl, endPoint, host, scheme;
    private Map<String, String> queryParams, formParams, cookies;
	Map<String, Object> body;
    private Headers headers;
    private RequestSpecification request;
    private Response response;
    private AuthenticationScheme authentication;
    private int port;
    private boolean isProxySet, isAunthenticationEnabled;

    /**
     * 
     * @param baseUrl
     * @param endPoint
     */
    public APIUtil(String baseUrl, String endPoint){
        this.baseUrl = baseUrl;
        this.endPoint = endPoint;
        this.queryParams = new HashMap<>();
        this.formParams = new HashMap<>();
        this.headers = new Headers();
        this.body = new HashMap<>();
        this.cookies = new HashMap<>();
        this.isProxySet = false;
        this.isAunthenticationEnabled = false;
    }

    
    /** 
     * @param queryParams
     */
    public void setQueryParams(Map<String, String> queryParams) {
        this.queryParams = queryParams;
    }

    
    /** 
     * @param formParams
     */
    public void setFormParams(Map<String, String> formParams) {
        this.formParams = formParams;
    }
    
    
    /** 
     * @param cookies
     */
    public void setCookies(Map<String, String> cookies) {
        this.cookies = cookies;
    }

    
    /** 
     * @param headers
     */
    public void setHeaders(Headers headers) {
        this.headers = headers;
    }
    
    
    /** 
     * @param body
     */
    public void setBody(Map<String, Object> body) {
        this.body = body;
    }

    
    /**
     * 
     * @param userName
     * @param password
     */
    public void setBasicAuthentication(String userName, String password) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.preemptive().basic(userName, password);
    }

    
    /** 
     * @param userName
     * @param password
     */
    public void setDigestAuthentication(String userName, String password) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.digest(userName, password);
    }

    
    /** 
     * @param userName
     * @param password
     */
    public void setFormAuthentication(String userName, String password) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.form(userName, password);
    }

    
    /**
     * 
     * @param userName
     * @param password
     * @param config
     */
    public void setFormAuthentication(String userName, String password, FormAuthConfig config) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.form(userName, password, config);
    }

    
    /** 
     * @param certUrl
     * @param password
     */
    public void setCertificateAuthentication(String certUrl, String password) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.certificate(certUrl, password);
    }

    
    /** 
     * @param certUrl
     * @param password
     * @param certificateAuthSettings
     */
    public void setCertificateAuthentication(String certUrl, String password, CertificateAuthSettings certificateAuthSettings) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.certificate(certUrl, password, certificateAuthSettings);
    }

    
    /** 
     * @param trustStorePath
     * @param trustStorePassword
     * @param keyStorePath
     * @param keyStorePassword
     * @param certificateAuthSettings
     */
    public void setCertificateAuthentication(String trustStorePath, String trustStorePassword, String keyStorePath, String keyStorePassword, CertificateAuthSettings certificateAuthSettings) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.certificate(trustStorePath, trustStorePassword, keyStorePath, keyStorePassword, certificateAuthSettings);
    }

    
    /** 
     * @param consumerKey
     * @param consumerSecret
     * @param accessToken
     * @param secretToken
     */
    public void setOauthAuthentication(String consumerKey, String consumerSecret, String accessToken, String secretToken) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.oauth(consumerKey, consumerSecret, accessToken, secretToken);
    }
    
    
    /** 
     * @param consumerKey
     * @param consumerSecret
     * @param accessToken
     * @param secretToken
     * @param signature
     */
    public void setOauthAuthentication(String consumerKey, String consumerSecret, String accessToken, String secretToken, OAuthSignature signature) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.oauth(consumerKey, consumerSecret, accessToken, secretToken, signature);
    }

    
    /** 
     * @param accessToken
     */
    public void setOauth2Authentication(String accessToken) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.oauth2(accessToken);
    }

    
    /** 
     * @param accessToken
     * @param signature
     */
    public void setOauth2Authentication(String accessToken, OAuthSignature signature) {
        this.isAunthenticationEnabled = true;
        this.authentication = RestAssured.oauth2(accessToken, signature);
    }
    
    /** 
     * @param host
     * @param port
     * @param scheme
     */
    public void setProxy(String host, int port, String scheme) {
        this.isProxySet = true;
        this.host = host;
        this.port = port;
        this.scheme = scheme;
    }

    private void init(){
        if(this.isAunthenticationEnabled)
            RestAssured.authentication = this.authentication;
        if(this.isProxySet)
            RestAssured.proxy(this.host, this.port, this.scheme);
        this.request = RestAssured.given(new APIBuilder().setuprequestspec())
        				.baseUri(this.baseUrl)
        				.relaxedHTTPSValidation()
        				.headers(this.headers)
        				.queryParams(this.queryParams)
        				.formParams(this.formParams)
        				.body(this.body)
        				.cookies(this.cookies);
    }

    public void invokeGET(){
       init();
       this.response = this.request.get(this.endPoint);
    }

    public void invokePOST(){
        init();
        this.response = this.request.post(this.endPoint);
    }

    public void invokePUT(){
        init();
        this.response = this.request.put(this.endPoint);
    }

    public void invokeDELETE(){
        init();
        this.response = this.request.delete(this.endPoint);
    }
    
    public void invokePATCH(){
        init();
        this.response = this.request.patch(this.endPoint);
    }

    
    /** 
     * @return Response
     */
    public Response getResponse() {
        return this.response;
    }
    
        
    /** 
     * @param json
     * @param pathToSchemaFile
     */
    public static void validateJsonSchema(String json, String pathToSchemaFile){
        assertThat(json, matchesJsonSchemaInClasspath(pathToSchemaFile));
    }
	

}
