package apimodel.objects;




/**
 * This class contains method to set and get values, which is similar to Login Payload file
 */
public class Login {


	private String username_or_email;
	private String password;
	private String subdomain;

	public String getUsername_or_email() {
		return username_or_email;
	}
	public void setUsername_or_email(String username_or_email) {
		this.username_or_email = username_or_email;
	}
	public String getSubdomain() {
		return subdomain;
	}
	public void setSubdomain(String subdomain) {
		this.subdomain = subdomain;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
