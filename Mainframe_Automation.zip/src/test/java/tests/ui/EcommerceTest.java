package tests.ui;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import init.BaseTest;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsTablesPage;
import utils.WebUtil;


public class EcommerceTest extends BaseTest{

	LoginPage loginPage;
	HomePage homePage;
	ProductsTablesPage productsTablesPage;
	WebUtil testUtil;
	
	
	@Parameters({"browserType", "appURL"})
	@BeforeMethod
	public void pageInit(String browserType, String appURL) {
		loginPage = new LoginPage();
		testUtil = new WebUtil();

		testUtil.launchBrowser(browserType, appURL);
	}

	/**
	 * This test method is created to verify the checkout functionality and dataprovide is used here to get data from excel
	 */    
	@Test(enabled=true,dataProvider = "ProductsTablesPageTest")
	public void selectProducttoChekout(String strTestcase, String strEmailID,String strPassword,String strMainProductSegment,String strSubProductSegment,String strProductDetails) {

		//  Writing test information to Extend Report
		getExtentTest().info("Application opened successfully");
		
		loginPage.navigateToLogin();

		getExtentTest().pass("Navigated to Login page");

		homePage = loginPage.login(strEmailID, strPassword);

		Assert.assertTrue(loginPage.validateHomePage().contains("Log out"));

		getExtentTest().pass("Logged into the application");

		productsTablesPage=homePage.selectProductTable("Search",strMainProductSegment);

		productsTablesPage.addTableToCart(strMainProductSegment);

		// *** Asserting the expected result
		Assert.assertTrue(productsTablesPage.validatecart().contains("product has been added"));

		productsTablesPage.closemsg("close popup");

		getExtentTest().pass("Product is Added to cart");
	}

	/**
	 * This test method is created to verify the checkout functionality and dataprovide is used here to get data from excel
	 */   
	@Test
	public void EcommerceLogin() {

		//  Writing test information to Extend Report
		getExtentTest().info("Application opened successfully");
		
		loginPage.navigateToLogin();

		getExtentTest().pass("Navigated to Login page");

		homePage = loginPage.login("test@wipro.com", "QET2021");

		Assert.assertTrue(loginPage.validateHomePage().contains("Log out"));

		getExtentTest().pass("Login functionality is valiadated");
	}

}
