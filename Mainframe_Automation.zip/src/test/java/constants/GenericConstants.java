package constants;

/**
 * This class is created to define all constants across all classes
 */
public class GenericConstants {

	// *** Generic Timeout constants ***

	public static long PAGE_LOAD_TIMEOUT = 05;
	public static long IMPLICIT_WAIT = 5;
	public static final long EXPLICIT_WAIT = 15;
	public static long API_WAIT = 10000;

}
