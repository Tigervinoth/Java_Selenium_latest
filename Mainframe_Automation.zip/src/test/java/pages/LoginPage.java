package pages;

import org.openqa.selenium.*;
import init.InitTest;
import utils.WebUtil;

import java.util.concurrent.TimeUnit;

public class LoginPage extends InitTest {

	WebUtil testUtil = new WebUtil();

	// *** UI elaments ***
	By signInSelect = By.xpath("//a[text()='Log in']");
	By emailAddress = By.id("Email");
	By password = By.id("Password");
	By signIn = By.xpath("//button[text()='Log in']");      
	By myAccountLabel = By.xpath("//a[text()='Log out']");


	/**
	 * This method is created to validate that the user has landed on home page after login
	 *
	 * @return
	 */
	public String validateHomePage() {
		getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		String accountLabel = getDriver().findElement(myAccountLabel).getText();
		return accountLabel;
	}

	/**
	 * This method is created to call login module
	 *
	 * @param username
	 * @param password
	 * @return HomePage
	 */
	public HomePage login(String userName, String pwd) {
		testUtil.sendKeys("User name field", emailAddress, userName);
		testUtil.sendKeys("Password Field", password, pwd);
		testUtil.click("Login", signIn);
		return new HomePage();
	}

	/**
	 * This method is created to login to the website
	 */
	public void navigateToLogin() {

		testUtil.click("Sign In", signInSelect);
	}

}
