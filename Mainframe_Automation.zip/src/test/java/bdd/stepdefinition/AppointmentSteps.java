package bdd.stepdefinition;

import org.testng.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HealthCareAppointmentPage;
import pages.HealthCareLoginPage;
import utils.WebUtil;



/**
 * This class contains stepdefinitions for the feature associated with booking medical appointment
 * Also individual steps
 */
public class AppointmentSteps {

	WebUtil testUtil = new WebUtil();
	HealthCareLoginPage login=new HealthCareLoginPage();
	HealthCareAppointmentPage appointment=null;

	@Given("user navigates to Healthcare website")
	public void user_navigates_to_healthcare_website() {

		testUtil.launchBrowser(testUtil.init_prop().getProperty("browser"),testUtil.init_prop().getProperty("hc_url"));
		login.clickOnAppoitment();

	}

	@Then("user should be directed to Home page of Healthcare app")
	public void user_should_be_directed_to_home_page_of_healthcare_app() {
				
		Assert.assertTrue(login.validateHomePage().equals(true));
		
	}

	@Then("user books an appointment with {string} {string} {string} {string}")
	public void user_books_an_appointment_with(String facility, String program, String date, String comment) {

		appointment.makeappointment(facility, program, date, comment);
		
		Assert.assertTrue(appointment.validateappointment().equals(true));
	}
	
	@When("^user logins with (.*) and (.*) on Healthcare app$")
	public void user_logins_with_and_on_healthcare_app(String user, String pwd) {
		
		appointment=login.login(user, pwd);
}

}
