package bdd.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsTablesPage;

import org.testng.Assert;

import utils.WebUtil;



/**
 * This class contains stepdefinitions for the feature associated with checking out the product from shopping cart
 */
public class ProductCheckoutSteps {

    LoginPage loginPage = new LoginPage();
    HomePage objHomePage = null;
    ProductsTablesPage objProductsTablesPage = null;
    WebUtil testUtil = new WebUtil();

    @Given("user navigates to ecommerce website")
    public void user_navigates_to_ecommerce_website() {
    	
    	testUtil.launchBrowser(testUtil.init_prop().getProperty("browser"),testUtil.init_prop().getProperty("hc_url"));
        loginPage.navigateToLogin();
    }

    @Then("^user should be directed to Home page$")
    public void page_title() {
        Assert.assertTrue(loginPage.validateHomePage().contains("Log out"));
    }

    @When("^user enters (.*) and (.*)$")
    public void enter_credential(String username, String password) {
        objHomePage = loginPage.login(username, password);
    }

    @Then("user searches for the {string}")
    public void user_searches_for_the(String strProductName) {
    	objProductsTablesPage=objHomePage.selectProductTable("Search",strProductName);
    }
    
    @And("^(.*) is added to Cart$")
    public void and_product_is_added_to_cart(String strProductName) {
    	
        objProductsTablesPage.addTableToCart(strProductName);
        
        Assert.assertTrue(objProductsTablesPage.validatecart().contains("product has been added"));
        objProductsTablesPage.closemsg("close popup");
    }

    @And("^(.*) is checked out$")
    public void and_product_is_checked_out(String strProductName) {
        objProductsTablesPage.clickCheckOut();
    }

    @Then("^selected (.*) should appear in the check out page$")
    public void then_selected_product_should_appear_in_the_check_out_page(String strProductName) {
        Assert.assertTrue(testUtil.getPageTitle().contains("Checkout"));
    }

    @Then("user should not be directed to Home page")
    public void user_should_not_be_directed_to_home_page() {
    	Assert.assertTrue(loginPage.validateHomePage().contains("My account"));
    }
    


}
