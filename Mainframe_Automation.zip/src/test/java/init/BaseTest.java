package init;

import com.aventstack.extentreports.Status;
import com.codoid.products.fillo.Recordset;
import org.testng.ITestContext;
import org.testng.ITestResult;
import utils.ExcelUtil;
import utils.WebUtil;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import java.lang.reflect.Method;


public class BaseTest extends InitTest {


	/**
	 * This before method initiates the test case details in report
	 */
	@BeforeMethod
	public void initializeTestBaseSetup(Method method) {

		// *** Initializing the report for test cases
		InitTest.initExtentTest(method.getName().toUpperCase(), "To verify the Expected test result for "+method.getName());

	}


	/**
	 * This after method writes test results to Extend Report and takes screenshots for Web
	 */
	@AfterMethod
	public void aftermethod(ITestResult result) {


		String screenshotPath = null;
		if (result.getStatus() == ITestResult.FAILURE) {

			getExtentTest().log(Status.FAIL, result.getName() + " failed due to below issues:");
			getExtentTest().fail(result.getThrowable());

			try {
				if(getDriver() != null) {
					screenshotPath = WebUtil.getScreenshot(result.getName());
					getExtentTest().addScreenCaptureFromBase64String(screenshotPath);
				}
			}catch(Exception e) {
				System.out.println("Driver is null");
			}

		}else if(result.getStatus() == ITestResult.SUCCESS){
			getExtentTest().log(Status.PASS, result.getName() + " passed");
		}

		if(getDriver() != null) {
			getDriver().quit();
		}
		getExtentTest().log(Status.INFO, "Test completed");
		objExtentReport.flush();
	}

	/**
	 * This dataprovider method fetches the data from excel based on the Test Name from XML file
	 */
	@DataProvider(name="ProductsTablesPageTest")
	public Object[][] getData(ITestContext objContext)
	{
		Object[][] objExcelData = new String[0][1];

		try {

			String strTestName = objContext.getCurrentXmlTest().getParameter("TestName");

			String strDataFileLocation = init_prop().getProperty("uiDataFile");

			ExcelUtil objExcelUtil = new ExcelUtil();

			Recordset objRS = objExcelUtil.getExcelData(strTestName,strDataFileLocation);

			int intRecordCounter = 0;
			int intDataCounter = 0;

			int intTotalFieldCount = objRS.getFieldNames().size();
			int intTotalRecordCount = objRS.getCount();

			String data[][] = new String[intTotalRecordCount][intTotalFieldCount - 1];

			while (objRS.next()) {
				while (intDataCounter < intTotalFieldCount-1) {
					data[intRecordCounter][intDataCounter] = objRS.getField(intDataCounter + 1).value();
					intDataCounter++;
				}
				intDataCounter =    0;
				intRecordCounter++;
			}

			objExcelData = data;

		} catch(Exception e)
		{
			System.out.println(e.getStackTrace());
		}
		return objExcelData;
	}

	/**
	 * This dataprovider method fetches the data from excel based on the Test Name from XML file
	 */
	@DataProvider(name="exceldata")
	public Object[][] getDataApi(ITestContext objContext)
	{
		Object[][] objExcelData = new String[0][1];

		try {

			String strTestName = objContext.getCurrentXmlTest().getParameter("TestName");

			String strDataFileLocation = init_prop().getProperty("apiDataFile");

			ExcelUtil objExcelUtil = new ExcelUtil();

			Recordset objRS = objExcelUtil.getExcelData(strTestName,strDataFileLocation);

			int intRecordCounter = 0;
			int intDataCounter = 0;

			int intTotalFieldCount = objRS.getFieldNames().size();
			int intTotalRecordCount = objRS.getCount();

			String data[][] = new String[intTotalRecordCount][intTotalFieldCount - 1];

			while (objRS.next()) {
				while (intDataCounter < intTotalFieldCount-1) {
					data[intRecordCounter][intDataCounter] = objRS.getField(intDataCounter + 1).value();
					intDataCounter++;
				}
				intDataCounter =    0;
				intRecordCounter++;
			}

			objExcelData = data;

		} catch(Exception e)
		{
			System.out.println(e.getStackTrace());
		}
		return objExcelData;
	}

}
